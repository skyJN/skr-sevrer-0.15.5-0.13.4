#!/bin/bash
cd "$(dirname "$0")"          # 进入 Skr/

pkill -f 'index.py' 2>/dev/null
pkill -f 'ws_server.py' 2>/dev/null
pkill -f 'sky0155-udp/src/main.js' 2>/dev/null
pkill -f 'exchange-server/main.js' 2>/dev/null
sleep 2

mkdir -p logs

# UDP
cd udp
nohup node src/main.js >> ../logs/udp.log 2>&1 &
sleep 2

# ws_server + index.py
cd ../skr
nohup python3 -u ws_server.py 2500 >> ../logs/ws.log 2>&1 &
sleep 1
nohup python3 -u index.py >> ../logs/web.log 2>&1 &
sleep 2

# exchange-server（注意目录名带空格）
cd "../skr starter/exchange-server"
nohup node main.js >> ../../logs/exchange.log 2>&1 &