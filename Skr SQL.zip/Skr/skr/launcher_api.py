# -*- coding: utf-8 -*-
"""launcher_api.py —— 启动器专属对接后台（SKR）。

启动器（skr_launcher）通过这组接口完成：
  1) /launcher/status    探测 HTTP / UDP / WS 三端是否在线
  2) /launcher/login     QQ号+邀请码 登录 -> 返回 UUID + session（自动建号）
  3) /launcher/udp       UDP 实时状态（房间 / 在线玩家 / 人数）
  4) /launcher/config    下发 UDP/WS/HTTP 连接参数（供启动器自动填端口）

本模块作为独立蓝图注册到 index.py，只做"启动器对接"，不碰游戏核心逻辑。
"""
import json
import os
import sys
import socket
import time
import uuid as _uuid
import secrets

from flask import Blueprint, request, jsonify

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import db as database

launcher_bp = Blueprint("launcher", __name__, url_prefix="/launcher")

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")

def _load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _tcp_ping(host, port, timeout=1.0):
    """尝试 TCP 连接探测某端口是否存活。"""
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True
    except Exception:
        return False

@launcher_bp.route("/status", methods=["GET", "POST"])
def launcher_status():
    """启动器探测服务器三端状态。

    返回：
      {
        "ok": true,
        "http": {"port": 3000, "online": true, "latency_ms": 12},
        "udp":  {"port": 25565, "online": true},
        "ws":   {"port": 2500, "online": true},
        "game_version": "..."
      }
    """
    cfg = _load_config()
    host = request.host.split(":")[0] or "127.0.0.1"
    http_port = int(cfg.get("launcher_http_port", 3000))
    udp_port = int(cfg.get("udp_server_port", 25565))
    ws_port = int(cfg.get("launcher_ws_port", 2500))

    t0 = time.time()
    http_ok = _tcp_ping(host, http_port)
    http_lat = int((time.time() - t0) * 1000)
    udp_ok = _tcp_ping(host, udp_port)
    ws_ok = _tcp_ping(host, ws_port)

    return jsonify({
        "ok": http_ok and udp_ok and ws_ok,
        "http": {"port": http_port, "online": http_ok, "latency_ms": http_lat},
        "udp": {"port": udp_port, "online": udp_ok},
        "ws": {"port": ws_port, "online": ws_ok},
        "game_version": cfg.get("client_version_default", 4852),
        "server_time": int(time.time()),
    })

@launcher_bp.route("/login", methods=["POST"])
def launcher_login():
    """启动器登录：QQ号 + 邀请码 -> UUID + session。

    请求: {"qq": "123456789", "code": "SKR-XXXX"}  （code 可省略，若绑定过则直接登录）
    行为:
      1) 校验 QQ 号
      2) 调 /invite/resolve 逻辑 -> 得到绑定的 UUID（未绑定则自动建号）
      3) 若提供 code，校验 code 是否匹配该 QQ 的绑定
      4) 生成 session 并返回
    返回: {ok, user_id, device_id, session, code, new, server_uri}
    """
    req = request.get_json(force=True, silent=True) or {}
    qq = str(req.get("qq", "")).strip()
    code = str(req.get("code", "")).strip()

    if not qq or not qq.isdigit() or len(qq) < 5:
        return jsonify({"ok": False, "error": "QQ号格式错误"}), 400

    # 1) 查已有绑定
    row = database.invite_get_by_qq(qq)
    if row and row.get("user_id"):
        user_id = row.get("user_id")
        if database.get_user_field(user_id, "id") is None:
            user_id = str(_uuid.uuid4())
            device_id = str(_uuid.uuid4())
            database.create_user(user_id, device_id, secrets.token_hex(32))
            database.execute(
                "UPDATE invite_codes SET user_id=? WHERE code=?",
                (user_id, row.get("code")))
        else:
            device_id = str(_uuid.uuid4())
        # 校验邀请码（若提供）
        if code and code.upper() != str(row.get("code", "")).upper():
            return jsonify({"ok": False, "error": "邀请码不匹配"}), 400
        new = False
    else:
        # 2) 未绑定 -> 自动建号
        user_id = str(_uuid.uuid4())
        device_id = str(_uuid.uuid4())
        recovery = secrets.token_hex(32)
        database.create_user(user_id, device_id, recovery)
        if not code:
            from route.invite import _gen_code
            code = _gen_code()
        database.invite_create(code, qq, user_id, note="启动器登录自动注册")
        new = True

    session = secrets.token_hex(16)
    # 下发 UDP 地址供启动器连接
    cfg = _load_config()
    udp_host = cfg.get("udp_server_host", "auto")
    if udp_host in ("", "auto", "0.0.0.0", "127.0.0.1", "localhost"):
        udp_host = request.host.split(":")[0]
    udp_port = int(cfg.get("udp_server_port", 25565))

    return jsonify({
        "ok": True,
        "user_id": user_id,
        "device_id": device_id,
        "session": session,
        "code": code,
        "new": new,
        "server_uri": {
            "http": "http://%s:%d" % (request.host.split(":")[0], int(cfg.get("launcher_http_port", 3000))),
            "udp": "%s:%d" % (udp_host, udp_port),
            "ws": "%s:%d" % (udp_host, int(cfg.get("launcher_ws_port", 2500))),
        },
    })

@launcher_bp.route("/udp", methods=["GET"])
def launcher_udp():
    """UDP 实时状态（房间 / 在线玩家）。

    返回：
      {
        "ok": true,
        "rooms": [{"id": "...", "name": "...", "players": 3, "level_id": "..."}],
        "total_online": 12,
        "udp_port": 25565
      }
    """
    try:
        from live_panel import build_payload
        payload = build_payload()
        return jsonify({
            "ok": True,
            "rooms": payload.get("rooms", []),
            "total_online": payload.get("online", 0),
            "udp_port": int(_load_config().get("udp_server_port", 25565)),
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)[:200]}), 500

@launcher_bp.route("/config", methods=["GET"])
def launcher_config():
    """下发服务器连接配置，供启动器自动填端口。"""
    cfg = _load_config()
    host = request.host.split(":")[0] or "127.0.0.1"
    return jsonify({
        "ok": True,
        "server": {
            "http_port": int(cfg.get("launcher_http_port", 3000)),
            "udp_port": int(cfg.get("udp_server_port", 25565)),
            "ws_port": int(cfg.get("launcher_ws_port", 2500)),
            "host": host,
            "game_version": cfg.get("client_version_default", 4852),
        }
    })

@launcher_bp.route("/test_auth", methods=["POST"])
def launcher_test_auth():
    """启动器「测试认证」：用 UUID 调 /account/auth/login 验证登录是否可用。

    请求: {"user_id": "uuid", "device_id": "uuid"}
    返回: {ok, session, message}
    """
    req = request.get_json(force=True, silent=True) or {}
    user = req.get("user_id") or req.get("user")
    device = req.get("device_id") or req.get("device")
    if not user or not device:
        return jsonify({"ok": False, "error": "缺少 user/device"}), 400

    # 复用 account 的登录放行判定
    try:
        from route.account import _login_user_ok
        if not _login_user_ok(user, device):
            return jsonify({"ok": False, "error": "user not found"}), 404
        return jsonify({
            "ok": True,
            "session": secrets.token_hex(16),
            "message": "认证成功",
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)[:200]}), 500