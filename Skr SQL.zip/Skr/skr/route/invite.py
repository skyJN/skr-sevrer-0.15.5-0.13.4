# -*- coding: utf-8 -*-
"""route/invite.py —— 邀请码登录系统（客户端公开接口）。

流程：
  管理员后台：输入 QQ 号 → 生成邀请码 → 自动创建 UUID 账号 → 绑定(QQ↔UUID)
  客户端：    输入 QQ 号 → POST /invite/resolve → 校验 → 返回绑定的 UUID
              启动器再用 UUID 调 /account/auth/login 自动登录并显示 UUID

本模块只暴露客户端会用到的公开接口：
  POST /invite/resolve   {qq}            -> {ok, user_id, code, new}
  GET  /invite/check     {qq}            -> {ok, user_id}（只查不建）
"""
import json
import os
import sys
import time
import secrets
import uuid as _uuid

from flask import Blueprint, request, jsonify

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import db as database

invite_bp = Blueprint("invite", __name__, url_prefix="/invite")

INVITE_PREFIX = "SKR"


def _gen_code():
    """生成格式化的邀请码：SKR-XXXXXXXX"""
    return "%s-%s" % (INVITE_PREFIX, secrets.token_hex(4).upper())


@invite_bp.route("/resolve", methods=["POST"])
def invite_resolve():
    """客户端用 QQ 号换取绑定账号 UUID。

    请求: {"qq": "123456789"}
    行为:
      1) 若该 QQ 已绑定邀请码/账号 -> 直接返回 user_id
      2) 若未绑定 -> 自动创建账号(UUID) + 生成邀请码并绑定
    返回: {"ok": true, "user_id": "...", "code": "...", "new": true/false}
    """
    req = request.get_json(force=True, silent=True) or {}
    qq = str(req.get("qq", "")).strip()
    if not qq or not qq.isdigit() or len(qq) < 5:
        return jsonify({"ok": False, "error": "QQ号格式错误"}), 400

    # 1) 查已有绑定
    row = database.invite_get_by_qq(qq)
    if row and row.get("user_id"):
        user_id = row.get("user_id")
        # 若账号被删则重建
        if database.get_user_field(user_id, "id") is None:
            user_id = str(_uuid.uuid4())
            device_id = str(_uuid.uuid4())
            database.create_user(user_id, device_id, secrets.token_hex(32))
            database.execute(
                "UPDATE invite_codes SET user_id=? WHERE code=?",
                (user_id, row.get("code")))
        return jsonify({
            "ok": True, "user_id": user_id,
            "code": row.get("code"), "new": False,
        })

    # 2) 未绑定 -> 自动建号 + 生成邀请码
    user_id = str(_uuid.uuid4())
    device_id = str(_uuid.uuid4())
    recovery = secrets.token_hex(32)
    database.create_user(user_id, device_id, recovery)

    code = _gen_code()
    for _ in range(5):  # 防碰撞
        if database.invite_get(code) is None:
            break
        code = _gen_code()
    database.invite_create(code, qq, user_id, note="客户端自动注册")

    return jsonify({
        "ok": True, "user_id": user_id, "code": code, "new": True,
    })


@invite_bp.route("/check", methods=["GET", "POST"])
def invite_check():
    """只查不建：根据 QQ 号返回绑定信息。"""
    req = request.get_json(force=True, silent=True) or {}
    qq = str(req.get("qq", "") or request.args.get("qq", "")).strip()
    if not qq:
        return jsonify({"ok": False, "error": "缺少 QQ 号"}), 400
    row = database.invite_get_by_qq(qq)
    if not row:
        return jsonify({"ok": False, "error": "未绑定", "qq": qq}), 404
    return jsonify({
        "ok": True, "user_id": row.get("user_id"),
        "code": row.get("code"), "qq": qq,
    })


@invite_bp.route("/status", methods=["GET"])
def invite_status():
    """给启动器显示邀请码/账号状态。"""
    qq = str(request.args.get("qq", "")).strip()
    if not qq:
        return jsonify({"ok": False, "error": "缺少 QQ 号"}), 400
    row = database.invite_get_by_qq(qq)
    if not row:
        return jsonify({"ok": False, "bound": False, "qq": qq})
    return jsonify({
        "ok": True, "bound": True,
        "user_id": row.get("user_id"), "code": row.get("code"),
        "status": row.get("status"), "qq": qq,
    })
