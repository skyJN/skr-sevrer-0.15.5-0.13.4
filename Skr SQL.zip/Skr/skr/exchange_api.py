# -*- coding: utf-8 -*-
"""exchange_api.py —— 启动器交换服务器（OAuth 邀请码登录）适配后台。

把 exchange-server（Node.js 版）的登录/邀请码/OAuth 逻辑用 Python/Flask
重写并注册成蓝图，对接 SKR 的 db.py（复用 invite_codes 表），
让 index.py 只需一行 import + register 即可启用，主体不用动。

功能接口（与 exchange-server 完全一致）：
  GET  /invite                     玩家发码网页
  POST /invite/api/issue           {qq, password} -> 生成/复用邀请码（含 UUID）
  POST /invite/api/query           {qq, password} -> 查自己的码
  POST /invite/api/bind_game_account {user_id, qq, device_id} -> 客户端上报绑定
  GET  /account/auth/oauth_signin  ?type=Invite&token=<邀请码> -> 302 重定向
  GET  /account/auth/oauth_redirect ?id&alias&signature&ts -> {id, alias, token}
  GET  /invite/status              服务状态 + 游戏服务器对接信息
  GET  /health | /healthz          健康检查

签名：HMAC-SHA256(user_id|alias|ts, secret)，与 Node hmacSign 一致。
存储：复用 SKR db 的 invite_codes 表（code/qq/user_id/device_id/status/...）。
      exchange 语义 status = active(可登录) / disabled(禁用)。
"""
import os
import re
import time
import json
import hmac
import hashlib
import secrets as _secrets
import uuid as _uuid

from flask import Blueprint, request, jsonify, redirect, Response

import db as database

exchange_bp = Blueprint("exchange", __name__)

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")


def _load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


# ---------- 工具函数（对齐 Node util.js） ----------
_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"


def gen_code(length=12):
    """生成邀请码（去掉易混淆字符 0O1lI），与 util.js 一致。"""
    out = []
    for _ in range(length):
        out.append(_ALPHABET[_secrets.randbelow(len(_ALPHABET))])
    return "".join(out)


def gen_uuid():
    """标准 v4 UUID，与 uuid.uuid4() 同格式。"""
    return str(_uuid.uuid4())


def hmac_sign(secret, payload):
    """HMAC-SHA256 十六进制签名，与 util.js hmacSign 一致。"""
    return hmac.new(secret.encode("utf-8"), payload.encode("utf-8"),
                    hashlib.sha256).hexdigest()


def safe_equal(a, b):
    """常量时间比对。"""
    a = "" if a is None else str(a)
    b = "" if b is None else str(b)
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def get_ip():
    return (request.headers.get("x-forwarded-for", "").split(",")[0].strip()
            or request.remote_addr or "")


def _cfg():
    return _load_config()


def _sign_secret():
    return _cfg().get("invite", {}).get("sign_secret") or _cfg().get("sign_secret") or "please-change-me"


def _admin_password():
    return _cfg().get("invite", {}).get("admin_password") or _cfg().get("admin_password") or "admin123"


def _invite_enabled():
    inv = _cfg().get("invite", {})
    return inv.get("enabled", True) if isinstance(inv, dict) else True


def _code_length():
    inv = _cfg().get("invite", {})
    return int(inv.get("code_length", 12)) if isinstance(inv, dict) else 12


# ---------- 存储：对接 db.invite_codes ----------
def _find_by_code(code):
    return database.query_one("SELECT * FROM invite_codes WHERE code = ?", (code,))


def _find_by_qq(qq):
    return database.query_one(
        "SELECT * FROM invite_codes WHERE qq = ? ORDER BY created_at DESC LIMIT 1", (qq,))


def _find_by_user_id(uid):
    return database.query_one("SELECT * FROM invite_codes WHERE user_id = ?", (uid,))


def _new_bind(qq, note, ip):
    """生成邀请码 + user_id/device_id(UUID)，写入 invite_codes(status=active)。"""
    code = gen_code(_code_length())
    while _find_by_code(code):
        code = gen_code(_code_length())
    user_id = gen_uuid()
    device_id = gen_uuid()
    now = int(time.time())
    database.execute(
        "INSERT INTO invite_codes(code, qq, user_id, note, status, device_id, created_at, used_at) "
        "VALUES (?, ?, ?, ?, 'active', ?, ?, 0)",
        (code, qq, user_id, note, device_id, now))
    return {"code": code, "qq": qq, "user_id": user_id, "device_id": device_id,
            "status": "active", "created_at": now, "note": note, "last_ip": ip}


def _issue_for_qq(qq, note, ip):
    bind = _find_by_qq(qq)
    if bind:
        return bind, True
    return _new_bind(qq, note, ip), False


def _gen_signature(user_id, alias, ts):
    return hmac_sign(_sign_secret(), "%s|%s|%s" % (user_id, alias, ts))


def _verify_signature(user_id, alias, ts, sig):
    if not sig or not user_id or not ts:
        return False
    return safe_equal(_gen_signature(user_id, alias or "", ts), sig)


def _is_valid_qq(qq):
    return bool(re.fullmatch(r"\d{4,20}", qq or ""))


# ---------- 网页（精简发码页） ----------
_INVITE_PAGE = """<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sky 私服 · 邀请码获取</title><style>
body{background:#0f1116;color:#e6e8ee;font:14px system-ui,sans-serif;padding:16px}
h1{font-size:17px}.card{background:#171a21;border:1px solid #262a34;border-radius:10px;padding:14px;margin:10px 0;max-width:420px}
label{display:block;margin:8px 0 4px;color:#8b93a5;font-size:12px}
input,button{width:100%;background:#0e1428;color:#fff;border:1px solid #262a34;border-radius:6px;padding:8px;font-size:13px;box-sizing:border-box}
button{background:#1c2536;cursor:pointer;margin-top:10px}
button:hover{border-color:#5cc8ff}
.ok{color:#59d18a}.err{color:#ff6b81}#msg{margin-top:8px;font-size:13px}
</style></head><body><h1>Sky 私服 · 邀请码获取</h1>
<div class="card"><label>QQ 号</label><input id="qq" placeholder="输入你的 QQ 号">
<label>管理员密码</label><input id="password" type="password" placeholder="向管理员索取">
<button onclick="issue()">获取 / 复用邀请码</button><div id="msg"></div></div>
<script>
async function issue(){var qq=document.getElementById('qq').value.trim(),p=document.getElementById('password').value;
var m=document.getElementById('msg');m.className='';m.textContent='...';
var r=await fetch('/invite/api/issue',{method:'POST',headers:{'Content-Type':'application/json'},
body:JSON.stringify({qq:qq,password:p})}).then(x=>x.json());
if(r.ok){m.className='ok';m.textContent='邀请码: '+r.code+'  (绑定账号: '+r.user_id+')';}
else{m.className='err';m.textContent=r.msg||'失败';}}
</script></body></html>"""


# ---------- 路由 ----------
@exchange_bp.route("/invite", methods=["GET"])
def invite_page():
    return Response(_INVITE_PAGE, mimetype="text/html; charset=utf-8")


@exchange_bp.route("/invite/api/issue", methods=["POST"])
def invite_api_issue():
    if not _invite_enabled():
        return jsonify({"ok": False, "msg": "邀请码功能已关闭"}), 403
    body = request.get_json(silent=True) or {}
    qq = str(body.get("qq", "")).strip()
    password = str(body.get("password", ""))
    if not _is_valid_qq(qq):
        return jsonify({"ok": False, "msg": "QQ 号格式不对（应为数字）"}), 400
    if not safe_equal(password, _admin_password()):
        return jsonify({"ok": False, "msg": "管理员密码不对"}), 401
    bind, reused = _issue_for_qq(qq, "", get_ip())
    return jsonify({"ok": True, "code": bind["code"], "qq": bind["qq"],
                    "user_id": bind["user_id"], "reused": reused})


@exchange_bp.route("/invite/api/query", methods=["POST"])
def invite_api_query():
    body = request.get_json(silent=True) or {}
    qq = str(body.get("qq", "")).strip()
    if not safe_equal(str(body.get("password", "")), _admin_password()):
        return jsonify({"ok": False, "msg": "管理员密码不对"}), 401
    bind = _find_by_qq(qq)
    if not bind:
        return jsonify({"ok": False, "msg": "该 QQ 还没有邀请码"}), 404
    return jsonify({"ok": True, "code": bind["code"], "qq": bind["qq"],
                    "user_id": bind["user_id"], "status": bind["status"]})


@exchange_bp.route("/invite/api/bind_game_account", methods=["POST"])
def invite_api_bind_game_account():
    """客户端上报游戏账号绑定（幂等）。"""
    body = request.get_json(silent=True) or {}
    uid = str(body.get("user_id", "")).strip()
    qq = str(body.get("qq", "")).strip()
    device_id = str(body.get("device_id", "")).strip()
    if not uid or not re.fullmatch(r"[0-9a-fA-F-]{36}", uid):
        return jsonify({"ok": False, "msg": "bad user_id"}), 400
    bind = _find_by_user_id(uid)
    if not bind and qq:
        bind = _find_by_qq(qq)
    if not bind:
        return jsonify({"ok": False, "msg": "未找到绑定记录(邀请码未兑换)"}), 404
    # 补 device_id
    if device_id and not bind.get("device_id"):
        database.execute("UPDATE invite_codes SET device_id=? WHERE code=?",
                         (device_id, bind["code"]))
    return jsonify({"ok": True, "user_id": bind["user_id"], "qq": bind["qq"],
                    "status": bind["status"]})


@exchange_bp.route("/account/auth/oauth_signin", methods=["GET"])
@exchange_bp.route("/account/auth/oauth_signin/", methods=["GET"])
def oauth_signin():
    """启动器填邀请码 -> 校验 -> 302 到 oauth_redirect 带签名。"""
    if not _invite_enabled():
        return jsonify({"ok": False, "msg": "invite disabled"}), 403
    stype = request.args.get("type", "")
    token = request.args.get("token", "")
    if stype != "Invite":
        return jsonify({"ok": False, "msg": "unsupported type: " + stype}), 400
    bind = _find_by_code(token)
    if not bind:
        return jsonify({"ok": False, "msg": "邀请码不存在"}), 403
    if bind["status"] != "active":
        return jsonify({"ok": False, "msg": "邀请码已禁用"}), 403
    now = int(time.time() * 1000)
    sig = _gen_signature(bind["user_id"], bind["qq"], str(now))
    proto = request.headers.get("x-forwarded-proto") or ("https" if _cfg().get("server", {}).get("https") else "http")
    host = request.host or ("localhost:" + str(_cfg().get("server", {}).get("port", 3000)))
    # 触发用户建档（auto_create_user_on_login 语义）
    try:
        if database.get_user_field(bind["user_id"], "id") is None:
            database.create_user(bind["user_id"], bind["device_id"] or gen_uuid(), _secrets.token_hex(32))
    except Exception:
        pass
    loc = "%s://%s/account/auth/oauth_redirect?id=%s&alias=%s&signature=%s&ts=%d" % (
        proto, host, bind["user_id"], bind["qq"], sig, now)
    return redirect(loc, code=302)


@exchange_bp.route("/account/auth/oauth_redirect", methods=["GET"])
@exchange_bp.route("/account/auth/oauth_redirect/", methods=["GET"])
def oauth_redirect_cb():
    """返回 {id, alias, token}，WebLogin.processLoading 期望格式。"""
    uid = request.args.get("id", "")
    alias = request.args.get("alias", "")
    ts = request.args.get("ts", "")
    signature = request.args.get("signature", "")
    bind = _find_by_user_id(uid)
    if not bind:
        return jsonify({"ok": False, "msg": "user not bound"}), 403
    if bind["status"] != "active":
        return jsonify({"ok": False, "msg": "invite disabled"}), 403
    if not _verify_signature(uid, alias, ts, signature):
        return jsonify({"ok": False, "msg": "signature invalid"}), 403
    return jsonify({"id": uid, "alias": alias, "token": signature})


@exchange_bp.route("/invite/status", methods=["GET"])
def invite_status():
    cfg = _cfg()
    gs = cfg.get("game_server", {}) or {}
    gh = str(gs.get("host", "")).strip()
    if not gh:
        gh = request.host.split(":")[0]
    return jsonify({
        "ok": True,
        "enabled": _invite_enabled(),
        "game_server": gs.get("display_name", "我的光遇私服"),
        "game_host": gh,
        "game_http_port": int(gs.get("http_port", 3000) or 3000),
        "game_udp_port": int(gs.get("udp_port", 25565) or 25565),
        "exchange": True,
    })


@exchange_bp.route("/health", methods=["GET"])
@exchange_bp.route("/healthz", methods=["GET"])
def exchange_health():
    try:
        count = database.query_one("SELECT COUNT(*) AS c FROM invite_codes")
        n = count["c"] if count else 0
    except Exception:
        n = -1
    return jsonify({"ok": True, "service": "sky-exchange-server", "binds": n,
                    "ts": int(time.time() * 1000)})