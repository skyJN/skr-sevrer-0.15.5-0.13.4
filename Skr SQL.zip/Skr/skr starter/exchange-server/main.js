'use strict';

/**
 * main.js — Sky 私服启动器 · 交换服务器（Exchange Server）入口
 *
 * 启动：node main.js [--port 4000] [--config config.json]
 *   --port    覆盖 config.server.port（临时换端口）
 *   --config  指定配置文件路径
 *
 * 零第三方依赖，只用 Node 内置模块：http / https / fs / crypto / url
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

// ---------- 配置加载 ----------
const DEFAULT_CONFIG = {
  server: { host: '0.0.0.0', port: 4000, https: false, cert_file: 'fullchain.pem', key_file: 'privkey.key' },
  admin: { password: 'admin123', session_minutes: 720 },
  invite: { enabled: true, code_length: 12, sign_secret: 'please-change-me', page_title: 'Sky 私服 · 邀请码获取' },
  game_server: { enabled: false, display_name: '我的光遇私服', host: '', http_port: 4000, udp_port: 25565 },
  storage: { data_file: 'data/binds.json' },
  motd: { title: '欢迎使用 Sky 私服', message: '请先获取邀请码，再在启动器内登录。' },
};

function parseArgs(argv) {
  const out = { port: null, config: null };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--port' && argv[i + 1]) out.port = parseInt(argv[i + 1], 10);
    if (argv[i] === '--config' && argv[i + 1]) out.config = argv[i + 1];
  }
  return out;
}

function deepMerge(base, extra) {
  const out = Object.assign({}, base);
  for (const k of Object.keys(extra || {})) {
    if (extra[k] && typeof extra[k] === 'object' && !Array.isArray(extra[k])
        && base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) {
      out[k] = deepMerge(base[k], extra[k]);
    } else {
      out[k] = extra[k];
    }
  }
  return out;
}

function loadConfig(args) {
  const cfgPath = args.config ? path.resolve(args.config) : path.resolve(__dirname, 'config.json');
  let userCfg = {};
  try {
    userCfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
  } catch (e) {
    console.warn('[config] 读取 config.json 失败，使用默认配置:', e.message);
  }
  const cfg = deepMerge(DEFAULT_CONFIG, userCfg);
  if (args.port) cfg.server.port = args.port;
  return cfg;
}

const args = parseArgs(process.argv.slice(2));
const CFG = loadConfig(args);

const store = require('./store');
store.init(CFG);

const { createRoutes } = require('./routes');
const { route } = createRoutes(CFG, store);

// ---------- HTTP 服务器 ----------
function handle(req, res) {
  let u;
  try {
    u = new URL(req.url, 'http://localhost');
  } catch (e) {
    res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: false, msg: 'bad url' }));
    return;
  }
  // 统一超时保护（避免挂死连接）
  req.setTimeout(30000, () => { try { req.destroy(); } catch (e) {} });
  try {
    route(req, res, u);
  } catch (e) {
    console.error('[main] 处理请求异常:', e);
    if (!res.headersSent) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ ok: false, msg: 'internal error' }));
    } else {
      try { res.end(); } catch (e2) {}
    }
  }
}

function listen() {
  let server;
  if (CFG.server.https) {
    const certFile = path.resolve(__dirname, CFG.server.cert_file);
    const keyFile = path.resolve(__dirname, CFG.server.key_file);
    let opts = null;
    try {
      opts = { cert: fs.readFileSync(certFile), key: fs.readFileSync(keyFile) };
    } catch (e) {
      console.error('[main] HTTPS 证书读取失败，退回 HTTP:', e.message);
      opts = null;
    }
    if (opts) {
      server = https.createServer(opts, handle);
    } else {
      server = http.createServer(handle);
    }
  } else {
    server = http.createServer(handle);
  }

  server.listen(CFG.server.port, CFG.server.host, () => {
    const proto = CFG.server.https && fs.existsSync(path.resolve(__dirname, CFG.server.cert_file)) ? 'https' : 'http';
    console.log('==============================================');
    console.log('  Sky 私服 · 交换服务器已启动');
    console.log('  ' + proto + '://' + CFG.server.host + ':' + CFG.server.port);
    console.log('  玩家发码页:  ' + proto + '://<服务器>:' + CFG.server.port + '/invite');
    console.log('  管理后台:    ' + proto + '://<服务器>:' + CFG.server.port + '/admin');
    console.log('  OAuth登录:   ' + proto + '://<服务器>:' + CFG.server.port + '/account/auth/oauth_signin?type=Invite&token=<邀请码>');
    console.log('==============================================');
  });

  server.on('error', (e) => {
    console.error('[main] 服务器错误:', e.message);
    process.exit(1);
  });

  // 优雅退出
  process.on('SIGINT', () => { console.log('\n收到退出信号'); store.saveNow(); process.exit(0); });
  process.on('SIGTERM', () => { store.saveNow(); process.exit(0); });
}

listen();