'use strict';

/**
 * store.js — 极简 JSON 文件存储层
 *
 * 所有数据都存在一个 JSON 文件里（默认 data/binds.json），
 * 修改后立即写盘。以后对接正式游戏服务器 / MySQL 时，
 * 只需要把本文件里的函数替换成数据库查询，对外接口不变。
 */
const fs = require('fs');
const path = require('path');

// ---------- 内部状态 ----------
let _cfg = null;
let _data = { binds: [] };        // binds: InviteBind[]
let _dirty = false;
let _saveTimer = null;

/**
 * InviteBind:
 * {
 *   code:        string  邀请码（玩家输入）
 *   qq:         string  绑定的 QQ 号
 *   user_id:    string  绑定的游戏账号 UUID（= 未来游戏服务器 users.id）
 *   device_id:  string  绑定的设备 UUID
 *   status:     'active' | 'disabled'
 *   created_at: number  (ms)
 *   last_login: number  (ms) 0 = 从未登录
 *   last_ip:    string
 *   note:       string  备注（可选）
 * }
 */

function init(config) {
  _cfg = config;
  const file = path.resolve(_cfg.storage.data_file);
  try {
    if (fs.existsSync(file)) {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
      _data = { binds: Array.isArray(raw.binds) ? raw.binds : [] };
    } else {
      _data = { binds: [] };
    }
    // 确保目录存在
    fs.mkdirSync(path.dirname(file), { recursive: true });
    saveNow();
  } catch (e) {
    console.error('[store] 读取数据文件失败，使用空数据:', e.message);
    _data = { binds: [] };
    fs.mkdirSync(path.dirname(file), { recursive: true });
    saveNow();
  }
}

function _file() {
  return path.resolve(_cfg.storage.data_file);
}

function saveNow() {
  try {
    fs.mkdirSync(path.dirname(_file()), { recursive: true });
    fs.writeFileSync(_file(), JSON.stringify(_data, null, 2));
    _dirty = false;
  } catch (e) {
    console.error('[store] 写盘失败:', e.message);
  }
}

function _scheduleSave() {
  _dirty = true;
  if (_saveTimer) return;
  _saveTimer = setTimeout(() => {
    _saveTimer = null;
    if (_dirty) saveNow();
  }, 500);
}

function _all() {
  return _data.binds;
}

// ---------- 查询 ----------
function findByCode(code) {
  if (!code) return null;
  return _all().find(b => b.code === code) || null;
}

function findByQq(qq) {
  if (!qq) return null;
  return _all().find(b => b.qq === qq) || null;
}

function findByUserId(uid) {
  if (!uid) return null;
  return _all().find(b => b.user_id === uid) || null;
}

function allBinds() {
  return _all().slice();
}

// ---------- 写入 ----------
function upsert(bind) {
  const list = _all();
  const idx = list.findIndex(b => (b.code && b.code === bind.code) || (b.qq && b.qq === bind.qq));
  if (idx >= 0) {
    list[idx] = Object.assign({}, list[idx], bind);
    _scheduleSave();
    return list[idx];
  }
  // 新绑定：push 后返回插入的那个对象（不能用 list[idx]，idx=-1 会是 undefined）
  const obj = Object.assign({}, bind);
  list.push(obj);
  _scheduleSave();
  return obj;
}

function removeByCode(code) {
  const list = _all();
  const idx = list.findIndex(b => b.code === code);
  if (idx < 0) return false;
  list.splice(idx, 1);
  _scheduleSave();
  return true;
}

// 变更一个字段并落盘
function patch(bind, fields) {
  Object.assign(bind, fields);
  _scheduleSave();
  return bind;
}

module.exports = {
  init,
  findByCode,
  findByQq,
  findByUserId,
  allBinds,
  upsert,
  removeByCode,
  patch,
  saveNow,
};