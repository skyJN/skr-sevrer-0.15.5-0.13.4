'use strict';

/**
 * routes.js — 路由处理（业务逻辑聚合层）
 *
 * 包含：
 *   · 玩家发码  /invite  + /invite/api/issue + /invite/api/query
 *   · 管理后台  /admin 页面 + /admin/api/*
 *   · OAuth 登录 /account/auth/oauth_signin + oauth_redirect（Canvas WebLogin 兼容）
 *   · 杂项 /health /healthz /invite/status
 */

const { genCode, genUuid, hmacSign, safeEqual, getIp } = require('./util');
const { invitePage, LOGIN_PAGE, ADMIN_PAGE } = require('./pages');
const { createMods } = require('./mods');

// 会话（内存，重启失效）
const sessions = new Map();

function createRoutes(cfg, store) {
  // ---------- 响应助手 ----------
  const json = (res, code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
  };
  const html = (res, code, content) => {
    res.writeHead(code, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(content);
  };
  const redirect = (res, url) => { res.writeHead(302, { Location: url }); res.end(); };

  // ---------- MOD 仓库实例 ----------
  const mods = createMods(cfg);

  // ---------- 会话 ----------
  function newSession() {
    const tok = genUuid().replace(/-/g, '') + genUuid().replace(/-/g, '');
    sessions.set(tok, { exp: Date.now() + (cfg.admin.session_minutes || 720) * 60 * 1000 });
    return tok;
  }
  function sessionUser(req) {
    const m = /sky_admin=([^;]+)/.exec(req.headers.cookie || '');
    if (!m) return null;
    const s = sessions.get(m[1]);
    if (!s) return null;
    if (s.exp < Date.now()) { sessions.delete(m[1]); return null; }
    return 'admin';
  }
  function setSessionCookie(res, tok) {
    const maxAge = (cfg.admin.session_minutes || 720) * 60;
    res.setHeader('Set-Cookie', `sky_admin=${tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`);
  }
  function clearSessionCookie(res) {
    res.setHeader('Set-Cookie', 'sky_admin=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
  }

  // ---------- 数据 ----------
  function newBind(qq, note, ip) {
    let code = genCode(cfg.invite.code_length || 12);
    while (store.findByCode(code)) code = genCode(cfg.invite.code_length || 12);
    const user_id = genUuid();
    const device_id = genUuid();
    return store.upsert({
      code, qq, user_id, device_id,
      status: 'active',
      created_at: Date.now(),
      last_login: 0,
      last_ip: ip,
      note: note || '',
    });
  }

  function issueForQq(qq, note, ip) {
    let bind = store.findByQq(qq);
    if (bind) return { bind, reused: true };
    return { bind: newBind(qq, note, ip), reused: false };
  }

  // ---------- 签名 ----------
  function genSignature(userId, alias, ts) {
    return hmacSign(cfg.invite.sign_secret, `${userId}|${alias}|${ts}`);
  }
  function verifySignature(userId, alias, ts, sig) {
    if (!sig || !userId || !ts) return false;
    return safeEqual(genSignature(userId, alias || '', ts), sig);
  }

  // ---------- 页面 ----------
  const handlers = {};

  // GET /invite → 玩家发码页
  handlers['GET /invite'] = (req, res) => html(res, 200, invitePage(cfg));
  handlers['GET /invite/'] = (req, res) => html(res, 200, invitePage(cfg));

  // POST /invite/api/issue → QQ+管理员密码 → 邀请码
  handlers['POST /invite/api/issue'] = (req, res) => {
    if (!cfg.invite.enabled) return json(res, 403, { ok: false, msg: '邀请码功能已关闭' });
    readJson(req).then((body) => {
      const qq = String(body.qq || '').trim();
      const password = String(body.password || '');
      if (!/^\d{4,20}$/.test(qq)) return json(res, 400, { ok: false, msg: 'QQ 号格式不对（应为数字）' });
      if (!safeEqual(password, cfg.admin.password)) return json(res, 401, { ok: false, msg: '管理员密码不对' });
      const { bind, reused } = issueForQq(qq, '', getIp(req));
      return json(res, 200, { ok: true, code: bind.code, qq: bind.qq, user_id: bind.user_id, reused });
    });
  };

  // POST /invite/api/query → 按 QQ 查码
  handlers['POST /invite/api/query'] = (req, res) => {
    readJson(req).then((body) => {
      const qq = String(body.qq || '').trim();
      if (!safeEqual(String(body.password || ''), cfg.admin.password)) return json(res, 401, { ok: false, msg: '管理员密码不对' });
      const bind = store.findByQq(qq);
      if (!bind) return json(res, 404, { ok: false, msg: '该 QQ 还没有邀请码' });
      return json(res, 200, { ok: true, code: bind.code, qq: bind.qq, user_id: bind.user_id, status: bind.status });
    });
  };

  // POST /invite/api/bind_game_account → 客户端上报游戏账号绑定（幂等）
  // 游戏登录 user_id 即 bind.user_id，服务器 auto_create_user_on_login 自动建档，
  // 因此授权过的账号进游戏即为已授权状态，无需管理面板二次操作。
  handlers['POST /invite/api/bind_game_account'] = (req, res) => {
    readJson(req).then((body) => {
      const uid = String(body.user_id || '').trim();
      const qq = String(body.qq || '').trim();
      const deviceId = String(body.device_id || '').trim();
      if (!uid || !/^[0-9a-fA-F-]{36}$/.test(uid)) return json(res, 400, { ok: false, msg: 'bad user_id' });
      let bind = store.findByUserId(uid);
      if (!bind && qq) bind = store.findByQq(qq);
      if (!bind) return json(res, 404, { ok: false, msg: '未找到绑定记录(邀请码未兑换)' });
      const patch = { game_account_confirmed: true, last_game_bind: Date.now() };
      if (deviceId && !bind.device_id) patch.device_id = deviceId;
      store.patch(bind, patch);
      return json(res, 200, { ok: true, user_id: bind.user_id, qq: bind.qq, status: bind.status });
    });
  };

  // ---------- 管理后台 ----------
  // GET /admin → 登录页或主页
  handlers['GET /admin'] = (req, res) => {
    if (!sessionUser(req)) return html(res, 200, LOGIN_PAGE);
    return html(res, 200, ADMIN_PAGE);
  };
  handlers['GET /admin/'] = (req, res) => {
    if (!sessionUser(req)) return html(res, 200, LOGIN_PAGE);
    return html(res, 200, ADMIN_PAGE);
  };

  // POST /admin/api/login
  handlers['POST /admin/api/login'] = (req, res) => {
    readJson(req).then((body) => {
      const user = String(body.user || '');
      const password = String(body.password || '');
      if (user === 'admin' && safeEqual(password, cfg.admin.password)) {
        const tok = newSession();
        setSessionCookie(res, tok); // 必须先设置 Cookie，再写响应体
        return json(res, 200, { ok: true, user: 'admin' });
      }
      return json(res, 401, { ok: false, msg: '用户名或密码不对' });
    });
  };

  // POST/GET /admin/api/logout
  handlers['POST /admin/api/logout'] = (req, res) => { clearSessionCookie(res); return json(res, 200, { ok: true }); };
  handlers['GET /admin/api/logout'] = (req, res) => { clearSessionCookie(res); return json(res, 200, { ok: true }); };

  // GET /admin/api/binds（需登录）
  handlers['GET /admin/api/binds'] = (req, res) => {
    if (!requireAdmin(req, res)) return;
    const list = store.allBinds().sort((a, b) => (b.created_at || 0) - (a.created_at || 0));
    return json(res, 200, { ok: true, binds: list });
  };

  // POST /admin/api/issue（需登录，管理员手发）
  handlers['POST /admin/api/issue'] = (req, res) => {
    if (!requireAdmin(req, res)) return;
    readJson(req).then((body) => {
      const qq = String(body.qq || '').trim();
      if (!/^\d{4,20}$/.test(qq)) return json(res, 400, { ok: false, msg: 'QQ 号格式不对' });
      const { bind, reused } = issueForQq(qq, String(body.note || ''), getIp(req));
      return json(res, 200, { ok: true, code: bind.code, qq: bind.qq, user_id: bind.user_id, reused });
    });
  };

  // POST /admin/api/bind/:code → enable/disable/del
  handlers['POST /admin/api/bind'] = (req, res, u) => {
    if (!requireAdmin(req, res)) return;
    const m = /^\/admin\/api\/bind\/([^/]+)$/.exec(u.pathname);
    if (!m) return json(res, 404, { ok: false, msg: 'not found' });
    const code = decodeURIComponent(m[1]);
    readJson(req).then((body) => {
      const bind = store.findByCode(code);
      if (!bind) return json(res, 404, { ok: false, msg: '邀请码不存在' });
      if (body.action === 'disable') { store.patch(bind, { status: 'disabled' }); return json(res, 200, { ok: true }); }
      if (body.action === 'enable') { store.patch(bind, { status: 'active' }); return json(res, 200, { ok: true }); }
      if (body.action === 'del') { store.removeByCode(code); return json(res, 200, { ok: true }); }
      return json(res, 400, { ok: false, msg: '未知操作' });
    });
  };

  // ---------- OAuth 登录（Canvas WebLogin 兼容） ----------
  // GET /account/auth/oauth_signin?type=Invite&token=<邀请码>
  handlers['GET /account/auth/oauth_signin'] = (req, res, u) => {
    if (!cfg.invite.enabled) return json(res, 403, { ok: false, msg: 'invite disabled' });
    const type = String(u.searchParams.get('type') || '');
    const token = String(u.searchParams.get('token') || '');
    if (type !== 'Invite') return json(res, 400, { ok: false, msg: 'unsupported type: ' + type });
    const bind = store.findByCode(token);
    if (!bind) return json(res, 403, { ok: false, msg: '邀请码不存在' });
    if (bind.status !== 'active') return json(res, 403, { ok: false, msg: '邀请码已禁用' });

    store.patch(bind, { last_login: Date.now(), last_ip: getIp(req) });

    const ts = Date.now();
    const sig = genSignature(bind.user_id, bind.qq, ts);
    const proto = req.headers['x-forwarded-proto'] || (cfg.server.https ? 'https' : 'http');
    const host = req.headers.host || ('localhost:' + cfg.server.port);
    const q = new URLSearchParams({ id: bind.user_id, alias: bind.qq, signature: sig, ts: String(ts) });
    return redirect(res, `${proto}://${host}/account/auth/oauth_redirect?${q.toString()}`);
  };
  handlers['GET /account/auth/oauth_signin/'] = handlers['GET /account/auth/oauth_signin'];

  // GET /account/auth/oauth_redirect → JSON {id, alias, token}（WebLogin.processLoading 期望）
  handlers['GET /account/auth/oauth_redirect'] = (req, res, u) => {
    const id = u.searchParams.get('id') || '';
    const alias = u.searchParams.get('alias') || '';
    const ts = u.searchParams.get('ts') || '';
    const signature = u.searchParams.get('signature') || '';
    const bind = store.findByUserId(id);
    if (!bind) return json(res, 403, { ok: false, msg: 'user not bound' });
    if (bind.status !== 'active') return json(res, 403, { ok: false, msg: 'invite disabled' });
    if (!verifySignature(id, alias, ts, signature)) return json(res, 403, { ok: false, msg: 'signature invalid' });
    return json(res, 200, { id, alias, token: signature });
  };
  handlers['GET /account/auth/oauth_redirect/'] = handlers['GET /account/auth/oauth_redirect'];

  // ---------- 杂项 ----------
  handlers['GET /health'] = (req, res) => json(res, 200, { ok: true, service: 'sky-exchange-server', binds: store.allBinds().length, ts: Date.now() });
  handlers['GET /healthz'] = handlers['GET /health'];
  handlers['GET /invite/status'] = (req, res) => {
    // game_host 为空时回退到请求方 host（单服务器场景：授权=游戏=同一台）
    let gh = (cfg.game_server.host || '').trim();
    if (gh.isEmpty && gh === '') gh = '';
    if (!gh) {
      gh = (req.headers.host || '').split(':')[0];
    }
    return json(res, 200, {
      ok: true, enabled: cfg.invite.enabled,
      game_server: cfg.game_server.display_name,
      game_host: gh,
      game_http_port: cfg.game_server.http_port,
      game_udp_port: cfg.game_server.udp_port,
    });
  };

  // ---------- MOD 仓库 ----------
  handlers['GET /mods/list'] = (req, res) => {
    return json(res, 200, { ok: true, mods: mods.publicList(req) });
  };
  handlers['GET /mods/manifest'] = (req, res) => {
    return json(res, 200, mods.rawManifest());
  };
  // GET /mods/<id>/download → 下载 zip（prefix 路由）
  handlers['GET /mods/download'] = (req, res, u) => {
    const m = /^\/mods\/([^/]+)\/download$/.exec(u.pathname);
    if (!m) return json(res, 404, { ok: false, msg: 'not found' });
    const id = decodeURIComponent(m[1]);
    const hit = mods.resolveFile(id);
    if (!hit) return json(res, 404, { ok: false, msg: 'MOD 不存在: ' + id });
    const fs2 = require('fs');
    const stat = fs2.statSync(hit.path);
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Length': stat.size,
      'Content-Disposition': 'attachment; filename="' + encodeURIComponent(id + '.zip') + '"',
      'Cache-Control': 'public, max-age=3600',
    });
    fs2.createReadStream(hit.path).pipe(res);
  };

// ---------- 分发 ----------
  // 精确匹配优先；带路径参数的接口走 prefix 回退
  const PREFIX_ROUTES = [
    ['POST', '/admin/api/bind/', 'POST /admin/api/bind'],
    ['GET', '/mods/', 'GET /mods/download'],
  ];
  function route(req, res, u) {
    const key = `${req.method} ${u.pathname}`;
    const fn = handlers[key];
    if (fn) return fn(req, res, u);
    // 前缀回退（路径参数接口，如 /admin/api/bind/<code>）
    for (const [method, prefix, handlerKey] of PREFIX_ROUTES) {
      if (req.method === method && u.pathname.startsWith(prefix)) {
        return handlers[handlerKey](req, res, u);
      }
    }
    // 兜底
    return json(res, 404, { ok: false, msg: 'not found', path: u.pathname });
  }

  function readJson(req) {
    return new Promise((resolve) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > 65536) { req.destroy(); resolve({}); return; }
        chunks.push(c);
      });
      req.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf8');
        if (!raw) return resolve({});
        try { resolve(JSON.parse(raw)); } catch (e) { resolve({}); }
      });
      req.on('error', () => resolve({}));
    });
  }

  function requireAdmin(req, res) {
    if (!sessionUser(req)) {
      json(res, 401, { ok: false, need_login: true, msg: '未登录' });
      return false;
    }
    return true;
  }

  return { route };
}

module.exports = { createRoutes };