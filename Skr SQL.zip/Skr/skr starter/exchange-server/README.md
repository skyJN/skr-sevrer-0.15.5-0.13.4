# Sky 私服 · 交换服务器（Exchange Server）

> 启动器应用的配套登录交换服务器。参考服务器只用来对照登录逻辑，**本服务独立运行，默认即可用**，以后拿它对接真正的游戏服务器。

## 它解决什么

玩家需要**邀请码登录**才能进游戏：

1. 管理员用 **网站** 给玩家发邀请码（输入 QQ 号 + 管理员密码 → 生成邀请码）
2. 邀请码在数据库里**绑定一个固定的游戏账号 UUID**
3. 玩家在**启动器里填邀请码** → 应用拿邀请码向本服务器兑换 → 得到绑定的 QQ + 游戏 ID → 用这个 ID 登录游戏
4. 换设备、重装：同一个邀请码 → 同一个游戏 ID → **账号数据全在游戏服务器，天然同步**

## 服务器部署

```bash
cd exchange-server
npm install      # 无第三方依赖，可跳过
node main.js     # 启动，默认 0.0.0.0:4000
```

需要脱离会话持续运行（Android 环境杀后台进程）：
```bash
setsid nohup node main.js --port 4000 > logs/exchange.log 2>&1 &
```

## 配置（config.json）

```jsonc
{
  "server":  { "host": "0.0.0.0", "port": 4000, "https": false, "cert_file": "...", "key_file": "..." },
  "admin":   { "password": "admin123", "session_minutes": 720 },
  "invite":  { "enabled": true, "code_length": 12, "sign_secret": "换成随机长字符串", "page_title": "..." },
  "game_server": {
    "enabled": false,          // 对接游戏服务器后改 true
    "display_name": "我的光遇私服",
    "host": "",                // 游戏服务器地址
    "http_port": 3000,         // 游戏 HTTP 端口
    "udp_port": 25565          // 游戏 UDP 端口
  },
  "storage": { "data_file": "data/binds.json" },
  "motd":    { "title": "...", "message": "..." }
}
```

- **admin.password**：发码用的管理员密码（默认 admin123，**上线必改**）
- **invite.sign_secret**：OAuth 签名密钥（**上线必改**）
- **game_server**：预留的对接项，现在不改也能跑；以后值换成你们游戏服务器即可

## 主要接口

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/invite` | 玩家发码网页（QQ+管理员密码） |
| POST | `/invite/api/issue` | `{qq, password}` → 生成/复用邀请码 |
| POST | `/invite/api/query` | `{qq, password}` → 查自己的码 |
| GET | `/admin` | 管理后台（登录） |
| GET | `/admin/api/binds` | 全部绑定（需登录） |
| POST | `/admin/api/issue` | 管理员手发码 |
| POST | `/admin/api/bind/:code` | 启用/禁用/删除 |
| GET | `/account/auth/oauth_signin?type=Invite&token=<邀请码>` | 启动器登录换 ID（302） |
| GET | `/account/auth/oauth_redirect?id=..&alias=..&signature=..` | 返回 `{id, alias, token}` |
| GET | `/health` `/healthz` | 健康检查 |
| GET | `/invite/status` | 服务状态 + 对接信息 |

## OAuth 登录流程（与 Canvas 启动器 WebLogin 兼容）

```
启动器 InputBox 填邀请码
  → GET /account/auth/oauth_signin?type=Invite&token=<邀请码>
  → 服务器校验邀请码 → 302 → /account/auth/oauth_redirect?id=<游戏ID>&alias=<QQ>&signature=<签名>&ts=<时间戳>
  → 客户端 GET oauth_redirect → JSON {id, alias, token}
  → 登录成功，游戏内以此 id 请求游戏服务器
```

## 数据文件

数据默认存在 `data/binds.json`（JSON 数组）。以后对接 MySQL / 正式游戏服务器时，替换 `store.js` 里的实现即可，接口不变。

## 目录结构

```
exchange-server/
├── main.js        # 入口（HTTP/HTTPS 服务）
├── config.json    # 配置
├── store.js       # JSON 存储层（可替换为数据库）
├── routes.js      # 路由与业务
├── pages.js       # 网页
├── util.js        # 工具函数
└── data/binds.json # 数据（自动生成）
```