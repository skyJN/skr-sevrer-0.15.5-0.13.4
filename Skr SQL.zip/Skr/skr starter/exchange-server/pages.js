'use strict';

/** pages.js — 交换服务器网页（发码页 / 管理登录页 / 管理主页） */

const { esc } = require('./util');

// 玩家自助发码页：QQ + 管理员密码 → 邀请码
function invitePage(cfg) {
  return `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(cfg.invite.page_title)}</title>
<style>
:root{--bg:#0b1020;--card:#151c33;--fg:#e8ecff;--dim:#8b96c0;--acc:#6ea8fe;--err:#ff6b81;--ok:#59d18a}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
 background:radial-gradient(1200px 600px at 20% -10%,#1b2a5e 0%,var(--bg) 60%);color:var(--fg);
 font:15px/1.6 system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;padding:16px}
.card{width:400px;max-width:100%;padding:28px;border-radius:18px;background:var(--card);
 box-shadow:0 20px 60px rgba(0,0,0,.45);border:1px solid #26304f}
h1{margin:0 0 8px;font-size:20px}
p.sub{margin:0 0 8px;color:var(--dim);font-size:13px}
label{display:block;margin:14px 0 6px;color:var(--dim);font-size:13px}
input{width:100%;padding:11px 12px;border-radius:10px;border:1px solid #2c3757;
 background:#0e1428;color:var(--fg);font-size:15px}
input:focus{outline:none;border-color:var(--acc)}
button{width:100%;margin-top:20px;padding:12px;border:0;border-radius:10px;cursor:pointer;
 background:linear-gradient(135deg,#4f8cff,#7b5cff);color:#fff;font-size:15px;font-weight:600}
button:disabled{opacity:.6;cursor:default}
.msg{margin-top:16px;font-size:14px;min-height:22px}
.msg.ok{color:var(--ok)} .msg.err{color:var(--err)}
.result{margin-top:14px;padding:14px;border-radius:10px;background:#0e1428;
 border:1px solid #2c3757;font-size:13px;color:var(--dim);line-height:1.8}
.result .code{font-size:22px;font-weight:700;letter-spacing:2px;color:var(--acc);
 font-family:ui-monospace,Consolas,monospace;user-select:all;text-align:center;padding:8px 0}
.hint{margin-top:18px;color:var(--dim);font-size:12px;line-height:1.7;
 border-top:1px dashed #2c3757;padding-top:12px}
</style></head><body>
<form class="card" id="f">
  <h1>${esc(cfg.invite.page_title)}</h1>
  <p class="sub">${esc(cfg.motd.title)}</p>
  <label>QQ 号</label>
  <input id="qq" inputmode="numeric" autocomplete="off" placeholder="请输入你的 QQ 号" autofocus>
  <label>管理员密码</label>
  <input id="p" type="password" autocomplete="current-password" placeholder="获取邀请码的管理员密码">
  <button id="b" type="submit">获取邀请码</button>
  <div class="msg" id="m"></div>
  <div class="result" id="r" style="display:none">
    <div>你的邀请码（复制后填进启动器即可登录）：</div>
    <div class="code" id="c"></div>
    <div>QQ：<span id="q"></span></div>
    <div>游戏账号：<span id="u"></span></div>
  </div>
  <div class="hint">${esc(cfg.motd.message)}</div>
</form>
<script>
const f=document.getElementById('f'),b=document.getElementById('b'),m=document.getElementById('m'),r=document.getElementById('r');
f.addEventListener('submit',async ev=>{
  ev.preventDefault();m.textContent='';m.className='msg';r.style.display='none';
  b.disabled=true;b.textContent='请稍候…';
  try{
    const resp=await fetch('/invite/api/issue',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({qq:document.getElementById('qq').value.trim(),password:document.getElementById('p').value})});
    const j=await resp.json();
    if(j.ok){
      document.getElementById('c').textContent=j.code;
      document.getElementById('q').textContent=j.qq;
      document.getElementById('u').textContent=j.user_id;
      r.style.display='block';
      m.className='msg ok';m.textContent=j.reused?'已为你复用原有邀请码':'获取成功！';
    }else{ m.className='msg err';m.textContent=j.msg||'获取失败'; }
  }catch(err){ m.className='msg err';m.textContent='请求失败: '+err; }
  b.disabled=false;b.textContent='获取邀请码';
});
</script></body></html>`;
}

// 管理后台登录页
const LOGIN_PAGE = `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>交换服务器 · 管理登录</title>
<style>
:root{--bg:#0b1020;--card:#151c33;--fg:#e8ecff;--dim:#8b96c0;--acc:#6ea8fe;--err:#ff6b81}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
 background:radial-gradient(1200px 600px at 20% -10%,#1b2a5e 0%,var(--bg) 60%);color:var(--fg);
 font:15px/1.6 system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
.card{width:340px;padding:28px;border-radius:18px;background:var(--card);
 box-shadow:0 20px 60px rgba(0,0,0,.45);border:1px solid #26304f}
h1{margin:0 0 4px;font-size:20px}
p.sub{margin:0 0 20px;color:var(--dim);font-size:13px}
label{display:block;margin:14px 0 6px;color:var(--dim);font-size:13px}
input{width:100%;padding:11px 12px;border-radius:10px;border:1px solid #2c3757;
 background:#0e1428;color:var(--fg);font-size:15px}
button{width:100%;margin-top:20px;padding:12px;border:0;border-radius:10px;cursor:pointer;
 background:linear-gradient(135deg,#4f8cff,#7b5cff);color:#fff;font-size:15px;font-weight:600}
.err{margin-top:14px;color:var(--err);font-size:13px;min-height:18px}
</style></head><body>
<form class="card" id="f">
  <h1>交换服务器 · 管理</h1>
  <p class="sub">邀请码 / 绑定管理</p>
  <label>用户名</label><input id="u" value="admin" autocomplete="username" autofocus>
  <label>密码</label><input id="p" type="password" autocomplete="current-password">
  <button id="b">登录</button>
  <div class="err" id="e"></div>
</form>
<script>
const f=document.getElementById('f'),b=document.getElementById('b'),e=document.getElementById('e');
f.addEventListener('submit',async ev=>{
  ev.preventDefault();e.textContent='';b.disabled=true;
  try{
    const r=await fetch('/admin/api/login',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({user:document.getElementById('u').value,password:document.getElementById('p').value})});
    const j=await r.json();
    if(j.ok){location.href='/admin/';return}
    e.textContent=j.msg||'登录失败';
  }catch(err){e.textContent='请求失败: '+err}
  b.disabled=false;
});
</script></body></html>`;

// 管理主页
const ADMIN_PAGE = `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>交换服务器 · 管理</title>
<style>
:root{--bg:#0f1116;--card:#171a21;--line:#262a34;--fg:#e6e8ee;--dim:#8b93a5;--acc:#5cc8ff;--err:#ff6b81;--ok:#59d18a}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.5 -apple-system,"Segoe UI",Roboto,"Microsoft YaHei",sans-serif}
header{padding:14px 18px;border-bottom:1px solid var(--line);display:flex;flex-wrap:wrap;gap:16px;align-items:center;background:#12151b;position:sticky;top:0;z-index:5}
h1{font-size:16px;margin:0 12px 0 0;font-weight:600}
.spacer{flex:1}
button,input{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:6px;padding:6px 10px;font-size:13px}
main{padding:14px;max-width:1100px}
section{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px;margin-bottom:14px}
section h2{margin:0 0 10px;font-size:14px;color:var(--dim);font-weight:600}
label{margin-right:8px;color:var(--dim)}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:6px 8px;border-bottom:1px solid #1e222b}
th{color:var(--dim);font-weight:500;font-size:12px}
td.code{font-family:ui-monospace,Consolas,monospace;color:var(--acc)}
.tag{font-size:11px;padding:1px 6px;border-radius:5px;background:#20303a}
.tag.on{color:var(--ok)} .tag.off{color:var(--err)}
.msg{color:var(--err);font-size:13px;min-height:18px;padding:6px 0}
</style></head><body>
<header><h1>交换服务器 · 管理</h1><div class="spacer"></div><button id="logout">退出</button></header>
<main>
  <section>
    <h2>手发邀请码</h2>
    <label>QQ：<input id="nq" placeholder="QQ 号" style="width:160px"></label>
    <label>备注：<input id="note" placeholder="备注（可选）" style="width:200px"></label>
    <button id="mk">生成邀请码</button>
    <div style="margin-top:8px" id="mkres"></div>
  </section>
  <section>
    <h2>全部绑定</h2>
    <div class="msg" id="msg"></div>
    <table><thead><tr><th>邀请码</th><th>QQ</th><th>游戏账号</th><th>状态</th><th>最近登录</th><th>操作</th></tr></thead><tbody id="rows"></tbody></table>
  </section>
</main>
<script>
const $=id=>document.getElementById(id);
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'"'}[c]));}
async function api(path,opt){
  const r=await fetch(path,Object.assign({},opt,{headers:{'Content-Type':'application/json'}}));
  const j=await r.json().catch(()=>({}));
  if(r.status===401){location.href='/admin/';return null;}
  return j;
}
async function load(){
  const j=await api('/admin/api/binds'); const t=$('rows'); t.innerHTML='';
  for(const b of (j.binds||[])){
    const tr=document.createElement('tr');
    const on=b.status==='active';
    tr.innerHTML='<td class="code">'+esc(b.code)+'</td><td>'+esc(b.qq)+'</td>'+
      '<td>'+esc(b.user_id)+'</td><td><span class="tag '+(on?'on':'off')+'">'+(on?'启用':'禁用')+'</span></td>'+
      '<td>'+(b.last_login?new Date(b.last_login).toLocaleString():'-')+'</td>'+
      '<td><button data-code="'+esc(b.code)+'" data-act="'+(on?'disable':'enable')+'">'+(on?'禁用':'启用')+'</button> '+
      '<button data-code="'+esc(b.code)+'" data-act="del" style="color:var(--err)">删除</button></td>';
    t.appendChild(tr);
  }
  t.querySelectorAll('button[data-code]').forEach(btn=>{
    btn.onclick=async()=>{
      const act=btn.dataset.act;
      if(act==='del'&&!confirm('确认删除该绑定？'))return;
      const j=await api('/admin/api/bind/'+encodeURIComponent(btn.dataset.code),{method:'POST',body:JSON.stringify({action:act})});
      if(j){ if(j.ok){$('msg').textContent=''; await load();} else $('msg').textContent=j.msg||'操作失败'; }
    };
  });
}
$('mk').onclick=async()=>{
  const j=await api('/admin/api/issue',{method:'POST',body:JSON.stringify({qq:$('nq').value.trim(),note:$('note').value.trim()})});
  if(j){ if(j.ok){$('mkres').textContent='已生成: '+j.code+' (QQ '+j.qq+' / 账号 '+j.user_id+')'; await load();} else $('msg').textContent=j.msg||'失败'; }
};
$('logout').onclick=async()=>{await api('/admin/api/logout',{method:'POST'});location.href='/admin/';};
load();
</script></body></html>`;

module.exports = { invitePage, LOGIN_PAGE, ADMIN_PAGE };