'use strict';

/**
 * mods.js — 文件式 MOD 仓库
 *
 * 目录约定：
 *   mods/                  MOD 根目录
 *     manifest.json        MOD 清单（管理员维护）
 *     <id>/mod.zip         MOD 压缩包（根目录含 data/）
 *
 * manifest.json 格式：
 * {
 *   "mods": [
 *     {
 *       "id": "unique-id",
 *       "name": "显示名",
 *       "version": "1.0.0",
 *       "author": "作者",
 *       "description": "说明",
 *       "file": "<id>/mod.zip",     // 相对 mods/ 的路径
 *       "size": 123456,               // 字节，可选（自动算）
 *       "md5": "...",                // 可选（校验用）
 *       "enabled": true
 *     }
 *   ]
 * }
 *
 * 接口：
 *   GET  /mods/list              → 启用中的 MOD 列表（不含内部字段，含下载URL）
 *   GET  /mods/<id>/download     → 下载 zip
 *   GET  /mods/manifest          → 原始清单（含 disabled，管理用）
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function createMods(cfg) {
  const modsDir = path.resolve(__dirname, 'mods');
  const manifestPath = path.join(modsDir, 'manifest.json');

  function loadManifest() {
    try {
      if (!fs.existsSync(manifestPath)) return { mods: [] };
      return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    } catch (e) {
      console.error('[mods] manifest 读取失败:', e.message);
      return { mods: [] };
    }
  }

  function fileSize(rel) {
    try {
      const p = path.join(modsDir, rel);
      if (!p.startsWith(modsDir)) return 0;
      const st = fs.statSync(p);
      return st.size || 0;
    } catch (e) {
      return 0;
    }
  }

  function resolveDownloadBase(req) {
    const proto = req.headers['x-forwarded-proto'] || (cfg.server.https ? 'https' : 'http');
    const host = req.headers.host || ('localhost:' + cfg.server.port);
    return proto + '://' + host;
  }

  function publicList(req) {
    const man = loadManifest();
    const base = resolveDownloadBase(req);
    return (man.mods || [])
      .filter(m => m && m.enabled !== false && m.id && m.file)
      .map(m => ({
        id: m.id,
        name: m.name || m.id,
        version: m.version || '',
        author: m.author || '',
        description: m.description || '',
        size: m.size || fileSize(m.file),
        md5: m.md5 || '',
        download_url: base + '/mods/' + encodeURIComponent(m.id) + '/download',
      }));
  }

  function rawManifest() {
    return loadManifest();
  }

  function resolveFile(id) {
    const man = loadManifest();
    const m = (man.mods || []).find(x => x && x.id === id && x.file);
    if (!m) return null;
    const p = path.join(modsDir, m.file);
    if (!p.startsWith(modsDir)) return null;   // 防目录穿越
    if (!fs.existsSync(p) || !fs.statSync(p).isFile()) return null;
    return { entry: m, path: p };
  }

  return { publicList, rawManifest, resolveFile, fileSize, modsDir };
}

module.exports = { createMods };
