'use strict';

/** util.js — 交换服务器通用工具函数（零依赖） */

const crypto = require('crypto');

// 生成邀请码（去掉易混淆字符 0O1lI）
function genCode(len) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  const bytes = crypto.randomBytes(len);
  let out = '';
  for (let i = 0; i < len; i++) out += alphabet[bytes[i] % alphabet.length];
  return out;
}

// 标准 v4 UUID（与参考服务器 uuid.uuid4() 同格式）
function genUuid() {
  const bytes = crypto.randomBytes(16);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const h = bytes.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

// HMAC-SHA256 签名
function hmacSign(secret, payload) {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

// 常量时间比对（防时序侧信道）
function safeEqual(a, b) {
  const x = Buffer.from(String(a == null ? '' : a), 'utf8');
  const y = Buffer.from(String(b == null ? '' : b), 'utf8');
  if (x.length !== y.length) {
    crypto.timingSafeEqual(x, x);
    return false;
  }
  return crypto.timingSafeEqual(x, y);
}

// 获取客户端 IP（尊重反代头）
function getIp(req) {
  return ((req.headers['x-forwarded-for'] || '').split(',')[0].trim())
    || req.socket.remoteAddress || '';
}

// HTML 转义
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&#34;');
}

module.exports = { genCode, genUuid, hmacSign, safeEqual, getIp, esc };