# 挂载 modadmin 到 routes.js（在服务器执行）
import sys

path = sys.argv[1] if len(sys.argv) > 1 else 'routes.js'
with open(path, 'r', encoding='utf-8') as f:
    src = f.read()

if "const { createModAdmin } = require('./modadmin');" not in src:
    src = src.replace(
        "const { createDevPanel } = require('./dev');",
        "const { createDevPanel } = require('./dev');\nconst { createModAdmin } = require('./modadmin');", 1)
    print('[1] require OK')

if 'const modadmin = createModAdmin' not in src:
    src = src.replace(
        '  const dev = createDevPanel(cfg, store);',
        '  const dev = createDevPanel(cfg, store);\n  const modadmin = createModAdmin(cfg, mods);', 1)
    print('[2] 实例化 OK')

if "handlers['GET /modadmin']" not in src:
    anchor = "  // ---------- 分发 ----------"
    routes = '''  // ---------- MOD 管理上传页 ----------
  handlers['GET /modadmin'] = (req, res) => {
    if (!requireAdmin(req, res)) return;
    return html(res, 200, modadmin.page());
  };
  handlers['GET /modadmin/'] = handlers['GET /modadmin'];

  handlers['POST /modadmin/api/upload'] = (req, res) => {
    if (!requireAdmin(req, res)) return;
    const u = new URL(req.url, 'http://localhost');
    const chunks = [];
    let size = 0;
    req.on('data', (c) => { size += c.length; if (size > 200*1024*1024) { req.destroy(); return; } chunks.push(c); });
    req.on('end', () => { const body = Buffer.concat(chunks); const r = modadmin.upload(body, u.searchParams); return json(res, r.ok ? 200 : 400, r); });
    req.on('error', () => json(res, 500, { ok: false, msg: 'upload error' }));
  };

  handlers['GET /modadmin/api/list'] = (req, res) => {
    if (!requireAdmin(req, res)) return;
    return json(res, 200, modadmin.list());
  };

  handlers['POST /modadmin/api/delete'] = (req, res) => {
    if (!requireAdmin(req, res)) return;
    readJson(req).then((body) => json(res, 200, modadmin.del(String(body.id || ''))));
  };

''' + anchor
    src = src.replace(anchor, routes, 1)
    print('[3] 路由 OK')

with open(path, 'w', encoding='utf-8') as f:
    f.write(src)
print('完成')
