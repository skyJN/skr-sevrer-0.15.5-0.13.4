'use strict';

/**
 * modadmin.js — MOD 管理上传页（/modadmin）
 * 管理员登录后上传 MOD zip，自动存入 mods/<id>/mod.zip 并更新 manifest.json
 */

const fs = require('fs');
const path = require('path');

function createModAdmin(cfg, mods) {
  const modsDir = mods.modsDir;
  const manifestPath = path.join(modsDir, 'manifest.json');

  function readManifest() {
    try {
      if (!fs.existsSync(manifestPath)) return { mods: [] };
      return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    } catch (e) { return { mods: [] }; }
  }
  function writeManifest(man) {
    try { fs.writeFileSync(manifestPath, JSON.stringify(man, null, 2), 'utf8'); return true; }
    catch (e) { return false; }
  }

  const PAGE = `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MOD 管理 · skr私服</title><style>
body{background:#0f1116;color:#e6e8ee;font:14px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;margin:0;padding:16px}
h1{font-size:17px}
.card{background:#171a21;border:1px solid #262a34;border-radius:10px;padding:14px;margin:10px 0;max-width:640px}
h2{font-size:14px;color:#8b93a5}
label{display:block;margin:8px 0 4px;color:#8b93a5;font-size:12px}
input,textarea{width:100%;background:#0e1428;color:#fff;border:1px solid #262a34;border-radius:6px;padding:8px;font-size:13px;box-sizing:border-box}
textarea{min-height:60px}
button{background:#1c2536;color:#fff;border:1px solid #3a4460;border-radius:6px;padding:8px 16px;margin-top:10px;cursor:pointer}
button:hover{border-color:#5cc8ff}
.row{display:flex;gap:10px}
.row>div{flex:1}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{padding:6px;border-bottom:1px solid #222;text-align:left}
th{color:#8b93a5;font-weight:500}
.ok{color:#59d18a}.err{color:#ff6b81}
#msg{margin-top:8px;font-size:13px;min-height:18px}
.del{color:#ff6b81;cursor:pointer}
a{color:#5cc8ff;text-decoration:none}
</style></head><body>
<h1>MOD 管理 · skr私服</h1>
<div class="card">
<label>ID（唯一英文标识）</label><input id="id" placeholder="fancy-cape">
<label>显示名</label><input id="name" placeholder="炫彩披风">
<div class="row"><div><label>版本</label><input id="version" value="1.0.0"></div><div><label>作者</label><input id="author" placeholder="skr"></div></div>
<label>描述</label><textarea id="desc" placeholder="MOD 说明…"></textarea>
<label>zip 文件（根目录含 data/ 的文件式 MOD）</label><input id="file" type="file" accept=".zip">
<button onclick="up()">上传 MOD</button>
<div id="msg"></div>
</div>
<div class="card"><h2>已上架 MOD</h2><table><thead><tr><th>ID</th><th>名称</th><th>版本</th><th>作者</th><th>操作</th></tr></thead><tbody id="rows"></tbody></table></div>
<script>
const $=x=>document.getElementById(x);
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'"',"'":'&#39;'}[c]));}
async function api(path,opt){const r=await fetch(path,Object.assign({},opt,{headers:{'Content-Type':'application/json'}}));const j=await r.json().catch(()=>({}));if(r.status===401)location.href='/dev/login';return j;}
async function up(){
  const f=$('file').files[0];const id=$('id').value.trim();
  if(!f||!id){$('msg').className='err';$('msg').textContent='请填 ID 并选择 zip 文件';return;}
  $('msg').className='';$('msg').textContent='上传中…';
  const q=new URLSearchParams({id,name:$('name').value.trim()||id,version:$('version').value.trim()||'1.0.0',author:$('author').value.trim(),description:$('desc').value.trim()});
  const r=await fetch('/modadmin/api/upload?'+q,{method:'POST',body:f});
  const j=await r.json().catch(()=>({}));
  $('msg').className=j&&j.ok?'ok':'err';
  $('msg').textContent=j&&j.ok?('上传成功 ✓ '+j.id+' v'+j.version+' ('+j.size+' 字节)'):((j&&j.msg)||'上传失败');
  if(j&&j.ok)load();
}
async function load(){
  const j=await api('/modadmin/api/list');if(!j||!j.ok)return;
  $('rows').innerHTML=(j.mods||[]).map(m=>'<tr><td>'+esc(m.id)+'</td><td>'+esc(m.name)+'</td><td>'+esc(m.version)+'</td><td>'+esc(m.author||'')+'</td><td><span class="del" onclick="del(\''+esc(m.id)+'\')">删除</span></td></tr>').join('');
}
async function del(id){if(!confirm('删除 '+id+' ？'))return;const j=await api('/modadmin/api/delete',{method:'POST',body:JSON.stringify({id})});if(j&&j.ok)load();}
load();
</script></body></html>`;

  return {
    page: () => PAGE,
    // 上传：body 为原始 zip 字节（Buffer）
    upload: (body, query) => {
      const id = String(query.get('id') || '').trim();
      if (!id) return { ok: false, msg: '缺少 ID' };
      if (!/^[A-Za-z0-9._-]+$/.test(id)) return { ok: false, msg: 'ID 只能是字母数字._-' };
      const size = body.length;
      const dir = path.join(modsDir, id);
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, 'mod.zip'), body);
      const man = readManifest();
      const entry = {
        id,
        name: query.get('name') || id,
        version: query.get('version') || '1.0.0',
        author: query.get('author') || '',
        description: query.get('description') || '',
        file: id + '/mod.zip',
        size,
        enabled: true,
        updated_at: Math.floor(Date.now() / 1000),
      };
      man.mods = (man.mods || []).filter(m => m.id !== id);
      man.mods.push(entry);
      if (!writeManifest(man)) return { ok: false, msg: 'manifest 写入失败' };
      return { ok: true, id: entry.id, version: entry.version, size };
    },
    list: () => ({ ok: true, mods: readManifest().mods || [] }),
    del: (id) => {
      const man = readManifest();
      const before = man.mods.length;
      man.mods = (man.mods || []).filter(m => m.id !== id);
      writeManifest(man);
      const dir = path.join(modsDir, id);
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {}
      return { ok: true, removed: before - man.mods.length };
    },
  };
}

module.exports = { createModAdmin };